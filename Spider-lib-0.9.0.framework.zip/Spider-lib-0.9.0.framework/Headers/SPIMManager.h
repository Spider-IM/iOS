/**
 * Copyright (c) 2019-2021, Spider.
 * All rights reserved.
 *
 * All the contents are the copyright of Spider Network Technology Co.Ltd.
 * Unless otherwise credited. http://Spider.cn
 *
 */

//  IMClient.h
//  Created by Spider on 20/6/20.

#ifndef __SpiderIMClient
#define __SpiderIMClient
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SPConnectionStatusListener.h"
#import "SPIMConfig.h"
#import "SPEnumDefine.h"
#import "SPMessage.h"
#import "SPSessionModel.h"
#import "SPMessageSendProfile.h"
#import "SPReceiveMessageListener.h"
#import "SPPlugin.h"

@interface SPIMManager : NSObject
@property (nonatomic, assign, readonly) SPConnectionStatus connectionStatus;
@property (nonatomic, copy, readonly) NSString *currentUserId;
#pragma 初始化与连接相关
+ (instancetype)sharedClient;

/*
添加接收消息的监听

 @param SPReceiveMessageListener
*/
- (BOOL)addMessageListener:(id<SPReceiveMessageListener>)listener;

/*
获取接收消息的监听

 @result SPReceiveMessageListener
*/
- (NSArray<id<SPReceiveMessageListener>> *)getReceiveMessageListener;

/*
移除接收消息的监听

 @param SPReceiveMessageListener
*/

- (BOOL)removeMessageListener:(id<SPReceiveMessageListener>)listener;

/*
添加连接状态变化的l监听

 @param SPConnectionStatusListener
*/

- (BOOL)addConnectionStatusListener:(id<SPConnectionStatusListener>)listener;

/*
移除连接状态变化的l监听

 @param SPConnectionStatusListener
*/

- (BOOL)removeConnectionStatusListener:(id<SPConnectionStatusListener>)listener;

/*
 初始化 SDK

 @param appkey
 @param config 配置
 */
- (bool)initWithAppkey:(NSString *)appkey config:(SPIMConfig *)config;

/**
 *  获取全局配置信息
 *
 *  @return 全局配置，详情请参考 SPIMConfig.h 中的 定义
 */
- (SPIMConfig *)getSPIMConfig;

/*!
设置推送的 deviceToken
*/
- (void)setDeviceToken:(NSData *)deviceToken;

/*
连接到服务器

@param userId  用户Id
@param token   用户鉴权信息
@param successBlock 成功回调
@param errorBlock 失败回调
*/
- (bool)connect:(NSString *)userId
           sign:(NSString *)token
        success:(void (^)(void))successBlock
          error:(void (^)(int errorCode))errorBlock;
/*
断开连接
*/
- (void)disConnect;

#pragma plugin

/*
注册插件，需在 connect 之前注册

 @param SPPlugin
*/
- (BOOL)registerPlugin:(id<SPPlugin>)plugin;

/*
卸载插件

 @param SPPlugin
*/
- (BOOL)unRegisterPlugin:(id<SPPlugin>)plugin;

#pragma 消息相关

/*
注册消息类型

@param messageClass 消息类
*/
- (void)registerMessageType:(Class)messageClass;
/*
发送消息

@param message  发送的 message ,message 对象的 和 content 以及 profile
不能为空，session 确定消息发送的目标，content 为消息的内容，profile 是消息属性
@param session  要发送到的 session
@param successBlock 成功回调
@param errorBlock 失败回调
@return SPMessage 更新 messageId
*/
- (SPMessage *)sendMessage:(SPMessage *)message
                 toSession:(SPSessionModel *)session
                   success:(void (^)(long messageId, NSString *uniqueId))successBlock
                     error:(void (^)(int errorCode, long messageId))errorBlock;
/*
获取本地存储的消息

@param session  要获取消息所属的会话
@param messageTypes   消息的类型集合
@param messageId 起始
@param isForward 获取消息的方向
@param count     获取的条数
@result  message 集合
*/
- (NSArray<SPMessage *> *)getMessages:(SPSessionModel *)session
                         messageTypes:(NSArray *)messageTypes
                            messageId:(long)messageId
                            direction:(BOOL)isForward
                                count:(int)count;

/*
获取本地存储的消息

@param messageId messageId
@result  message 消息
*/
- (SPMessage *)getMessage:(long)messageId;

/*!
 删除本地数据库存储的消息

 @param messageIds  消息 ID 的列表，元素需要为 NSNumber 类型
 @return            是否删除成功

 @remarks 消息操作
 */
- (BOOL)deleteMessages:(NSArray<NSNumber *> *)messageIds;

/*!
 删除本地数据库存储该会话的消息

 @param session  会话
 @return            是否删除成功

 @remarks 消息操作
 */
- (BOOL)deleteSessionMessages:(SPSessionModel *)session;

#pragma 会话相关
/*
获取本地的会话列表

@param sessionTypes  会话类型的集合
@result session  集合
*/
- (NSArray<SPSessionModel *> *)getSessionList:(NSArray *)sessionTypes;

/*
获取本地的会话

@param sessionId  会话Id
@param sessionType 会话类型
@result SPSessionModel 会话 model
*/
- (SPSessionModel *)getSession:(NSString *)sessionId sessionType:(SPSessionType)sessionType;

/*
删除本地的会话

@param sessionId  会话Id
@param sessionType 会话类型
@result result 成功失败
*/
- (BOOL)deleteSession:(SPSessionModel *)session;

/*
更新本地的会话制定状态

@param sessionId  会话Id
@param sessionType 会话类型
@param isTop 是否制定
*/
-(BOOL)updateSessionTopStatus:(SPSessionModel *)session isTop:(BOOL)isTop;
/*
 清理会话的未读状态
 */
-(BOOL)clearSessionUnreadStatus:(SPSessionModel *)session;

/*
 更新消息的发送状态
 */
- (BOOL)updateMessageSentStatus:(long)messageId sentStatus:(SPMessageSentStatus)sentStatus;

#pragma 未读数

/**
 获取某些类型的会话中所有的未读消息数

 @param sessionTypes   会话类型的数组
 @return             该类型的会话中所有的未读消息数
 */
- (int)getUnreadCount:(NSArray *)sessionTypes;
@end

#endif
