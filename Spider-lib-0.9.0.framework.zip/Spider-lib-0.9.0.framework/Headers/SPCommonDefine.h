/**
 * Copyright (c) 2019-2021, Spider.
 * All rights reserved.
 *
 * All the contents are the copyright of Spider Network Technology Co.Ltd.
 * Unless otherwise credited. http://Spider.cn
 *
 */

//  SPCommonDefine.h
//  Created by Sipder on 14-4-21.

#import <Foundation/Foundation.h>

//---------------Macro Definination---------//
/**************************************************
 Description: Used for ARC mode or not.
 Author:    Hequn
 ***************************************************/

#define SP_IOS_SYSTEM_VERSION_EQUAL_TO(v)                                                                              \
    ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SP_IOS_SYSTEM_VERSION_GREATER_THAN(v)                                                                          \
    ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SP_IOS_SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)                                                              \
    ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SP_IOS_SYSTEM_VERSION_LESS_THAN(v)                                                                             \
    ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SP_IOS_SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)                                                                 \
    ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

#ifdef DEBUG
#define DLog(s,...) NSLog(@"%s LINE:%d < %@ >",__FUNCTION__, __LINE__, [NSString stringWithFormat:(s), ##__VA_ARGS__]);
#define DMethod() NSLog(@"%s", __func__);
#else
#define DLog(...);
#define DMethod();
#endif
