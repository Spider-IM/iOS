//
//  SPTools.h
//  Spider-lib
//
//  Created by spider on 2020/9/1.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SPUtilities : NSObject
+(UIImage *)generateThumbnail:(UIImage *)image targetSize:(CGSize)targetSize;
+(NSString *)base64EncodedStringFrom:(NSData *)data;
+(NSData *)dataWithBase64EncodedString:(NSString *)string;
+ (NSString *)getDeviceId:(NSString *)appKey ;
+ (NSString *)getUUID;
+(NSString*)encodeString:(NSString*)unencodedString;
@end

NS_ASSUME_NONNULL_END
