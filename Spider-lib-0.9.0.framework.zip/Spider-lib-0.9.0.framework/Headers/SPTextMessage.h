//
//  SPTextMessage.h
//  Spider-lib
//
//  Created by Spider on 2020/6/12.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPMessageContent.h"
NS_ASSUME_NONNULL_BEGIN

#define SPTextMessageName @"SP:TxtMsg"

@interface SPTextMessage:SPMessageContent
/**
 构造方法

 @param text 文本
 @return 文本消息
 */
+ (instancetype)initWithString:(NSString *)text;

/**
 文本内容
 */
@property (nonatomic, copy)NSString *text;

@end

NS_ASSUME_NONNULL_END
