//
//  SPMessageReceiveDelegate.h
//  Spider-lib
//
//  Created by Spider on 2020/6/15.
//  Copyright © 2020 Spider. All rights reserved.
//

#ifndef SPMessageReceiveDelegate_h
#define SPMessageReceiveDelegate_h
@class SPMessage;

@protocol SPReceiveMessageListener <NSObject>

- (void)onReceived:(SPMessage *)message left:(int)nLeft object:(id)object;

@end
#endif /* SPMessageReceiveDelegate_h */
