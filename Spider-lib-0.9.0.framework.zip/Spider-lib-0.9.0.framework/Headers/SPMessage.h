//
//  SPMessage.h
//  Spider-lib
//
//  Created by Spider on 2020/6/12.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPSessionModel.h"
#import "SPMessageContent.h"
#import "SPMessageSendProfile.h"

NS_ASSUME_NONNULL_BEGIN

@interface SPMessage : NSObject
/**
 消息在本地数据库存储的 Id
 */
@property (nonatomic, assign, readonly) long messageId;

/*!
 消息在服务器唯一 Id
 */
@property (nonatomic, copy) NSString *uniqueId;

/**
 消息所属的会话 Id
 */
@property (nonatomic, copy) NSString *sessionId;

/**
消息所属的会话类型
*/
@property (nonatomic, assign) SPSessionType sessionType;

/**
 消息内容
 */
@property (nonatomic, strong, readonly, nullable) SPMessageContent *content;

/**
 消息发送时的属性
 */
@property (nonatomic, strong, readonly) SPMessageSendProfile *profile;

/**
 消息类型
 */
@property (nonatomic, copy, readonly) NSString *messageType;

/**
 消息发送者的用户ID
 */
@property (nonatomic, copy, readonly) NSString *senderId;

/**
 消息方向
 */
@property (nonatomic, assign, readonly) SPMessageDirection direction;

/*!
 消息的发送状态
 */
@property (nonatomic, assign) SPMessageSentStatus sentStatus;

/**
 消息的发送时间
 */
@property (nonatomic, assign) long long sentTime;

/**
 消息的接收时间
 */
@property (nonatomic, assign, readonly) long long receivedTime;

/**
 消息的接收时间
 */
@property (nonatomic, copy, readonly) NSString *digest;

- (instancetype)initMessageWithSessionId:(NSString *)sessionId
                             sessionType:(SPSessionType)sessionType
                                 content:(SPMessageContent *)content
                                 profile:(SPMessageSendProfile *)profile;

- (instancetype)initMessageWithMessageId:(long)messageId
                               sessionId:(NSString *)sessionId
                             sessionType:(SPSessionType)sessionType
                                 content:(SPMessageContent *)content
                                 profile:(SPMessageSendProfile *)profile
                                senderId:(NSString *)senderId
                                sentTime:(long long)sentTime
                            receivedTime:(long long)receivedTime
                              sentStatus:(SPMessageSentStatus)sentStatus
                                uniqueId:(NSString *)uniqueId;

@end

NS_ASSUME_NONNULL_END
