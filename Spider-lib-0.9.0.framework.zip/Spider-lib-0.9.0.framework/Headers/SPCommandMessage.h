//
//  SPCommandMessage.h
//  Spider-lib
//
//  Created by spider on 2020/8/19.
//  Copyright © 2020 Spider. All rights reserved.
//

#import "SPMessageContent.h"
NS_ASSUME_NONNULL_BEGIN

#define SPCommandMessageName @"SP:CmdMsg"

@interface SPCommandMessage:SPMessageContent
/**
 构造方法

 @param 指令名称
 @param 指令json数据
 @return 实例
 */
+ (instancetype)initWithCommand:(NSString *)command jsonData:(NSString *)json;

/**
 指令名称
 */
@property (nonatomic, copy)NSString *command;

/**
 指令数据
 */
@property (nonatomic, copy)NSString *jsonData;

@end
NS_ASSUME_NONNULL_END
