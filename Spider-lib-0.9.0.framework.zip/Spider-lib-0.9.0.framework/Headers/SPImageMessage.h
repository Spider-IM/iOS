//
//  SPImageMessage.h
//  Spider-lib
//
//  Created by spider on 2020/9/1.
//  Copyright © 2020 Spider. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SPMessageContent.h"
NS_ASSUME_NONNULL_BEGIN

#define SPImageMessageName @"SP:ImageMsg"

@interface SPImageMessage:SPMessageContent
/**
 构造方法

 @param UIImage  图片
 @return 消息
 */
- (instancetype)initWithImage:(UIImage *)image;
/*!
 图片消息的 URL 地址

 @discussion 发送方此字段为图片的本地路径，接收方此字段为网络 URL 地址。
 */
@property (nonatomic, copy) NSString *imageUrl;

/*!
 图片的本地路径
 */
@property (nonatomic, copy) NSString *localPath;

/*!
 图片消息的缩略图
 */
@property (nonatomic, strong) UIImage *thumbnailImage;

/*!
 图片消息的原始图片信息
 */
@property (nonatomic, strong) UIImage *originalImage;

/*!
 图片消息的原始图片信息
 */
@property (nonatomic, strong, readonly) NSData *originalImageData;

@end

NS_ASSUME_NONNULL_END
