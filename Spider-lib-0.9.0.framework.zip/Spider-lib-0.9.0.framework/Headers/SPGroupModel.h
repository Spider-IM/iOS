//
//  SPGroupModel.h
//  Spider-lib
//
//  Created by spider on 2021/3/29.
//  Copyright © 2021 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SPGroupModel : NSObject

/*!
 用户 ID
 */
@property (nonatomic, copy) NSString *groupId;

/*!
 用户名称
 */
@property (nonatomic, copy) NSString *groupName;

/*!
 用户头像的 URL
 */
@property (nonatomic, copy) NSString *groupPortrait;

/**
 用户信息附加字段
 */
@property (nonatomic, copy) NSString *extra;

- (SPGroupModel *)initWithGroupId:(NSString *)groupId groupName:(NSString *)groupName groupPortrait:(NSString *)groupPortrait;
@end

NS_ASSUME_NONNULL_END
