//
//  SPNoticeMessage.h
//  Spider-lib
//
//  Created by spider on 2020/8/19.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPMessageContent.h"
NS_ASSUME_NONNULL_BEGIN

#define SPNoticeMessageName @"SP:NoticeMsg"

@interface SPNoticeMessage:SPMessageContent
/**
 构造方法

 @param notice名称
 @param notice json数据
 @return 实例
 */
+ (instancetype)initWithNotice:(NSString *)notice jsonData:(NSString *)json;

/**
 notice 名称
 */
@property (nonatomic, copy)NSString *notice;

/**
 数据
 */
@property (nonatomic, copy)NSString *jsonData;

@end
NS_ASSUME_NONNULL_END
