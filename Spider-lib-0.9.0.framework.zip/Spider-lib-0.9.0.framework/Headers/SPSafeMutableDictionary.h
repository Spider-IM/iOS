//
//  SPSafeMutableDictionary.h
//  Spider-lib
//
//  Created by spider on 2020/9/7.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SPSafeMutableDictionary : NSMutableDictionary <NSLocking>

@end

NS_ASSUME_NONNULL_END
