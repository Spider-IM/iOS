//
//  SPMessageContent.h
//  Spider-lib
//
//  Created by Spider on 2020/6/16.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPEnumDefine.h"

/**
 消息协议，所有消息(包括自定义消息均需要实现此协议)
 */
@protocol SPMessageContentProtocol <NSObject>

/**
 消息编码

 @return 消息的持久化内容
 */
- (NSData *)encode;

/**
 消息解码

 @param payload 消息的持久化内容
 */
- (void)decode:(NSData *)payload;

/**
 消息类型，必须全局唯一。1000及以下为系统内置类型，自定义消息需要使用1000以上。

 @return 消息类型的唯一值
 */
+ (NSString *)getMessageType;

/**
 消息的存储策略

 @return 存储策略
 */
+ (SPMessageProfileType)getMessageProfileType;

/**
 消息的简短信息

 @return 消息的简短信息，主要用于通知提示和会话列表等需要简略信息的地方。
 */
- (NSString *)getMessageDigest;
@end

/**
 消息内容，自定义消息可以继承此类
 */
@interface SPMessageContent : NSObject <SPMessageContentProtocol>

/**
 推送内容
*/
@property (nonatomic, copy)NSString *pushContent;

/**
 消息原始内容
 */
@property (nonatomic, strong)NSData *originalData;

/**
 附加信息
 */
@property (nonatomic, strong)NSDictionary *extra;

/**
 摘要信息，在会话列表最后一条消息处显示
 */
@property (nonatomic, strong)NSString *digest;
@end

