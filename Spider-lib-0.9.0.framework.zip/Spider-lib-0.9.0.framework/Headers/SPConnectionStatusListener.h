//
//  SPConnectionDeleage.h
//  Spider-lib
//
//  Created by Spider on 2020/6/9.
//  Copyright © 2020 Spider. All rights reserved.
//

#ifndef SPConnectionDeleage_h
#define SPConnectionDeleage_h
/**
 *  登录相关回调
 */
@protocol SPConnectionStatusListener <NSObject>
@optional
-(void)onConnecting;
 
-(void)onConnected;

-(void)onOpenDB:(int)code;

-(void)onDisconnect:(int)code describe:(NSString *)describe;;
 
-(void)onKickedOffline:(NSString *)describe;

@end

#endif /* SPConnectionDeleage_h */
