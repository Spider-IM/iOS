//
//  SPSessionModel.h
//  Spider-lib
//
//  Created by Spider on 2020/6/12.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPEnumDefine.h"
//#import "<#header#>"

@class SPMessage;
NS_ASSUME_NONNULL_BEGIN
@interface SPSessionModel : NSObject
@property (nonatomic,copy) NSString *sessionId;
@property (nonatomic,assign) SPSessionType sessionType;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,strong) SPMessage *lastestMessage;
@property (nonatomic,assign) BOOL isTop;
@property (nonatomic,assign) BOOL isSilence;
@property(nonatomic,assign)long long updateTime;
@property (nonatomic,assign) int unreadCount;
@property (nonatomic, copy) NSString *draft;
- (instancetype)initWithSessionType:(SPSessionType)sessionType sessionId:(NSString *)sessionId;
@end

NS_ASSUME_NONNULL_END
