//
//  SPMessageProfile.h
//  Spider-lib
//
//  Created by spider on 2020/6/30.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SPEnumDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface SPMessageSendProfile : NSObject
@property(nonatomic,assign)BOOL *isSendPush;
@property(nonatomic,copy)NSString *pushContent;
@property(nonatomic,copy)NSString *pushData;
@end

NS_ASSUME_NONNULL_END
