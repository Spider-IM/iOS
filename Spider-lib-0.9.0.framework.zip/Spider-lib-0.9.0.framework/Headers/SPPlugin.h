//
//  SPPluginDelegate.h
//  Spider-lib
//
//  Created by spider on 2021/5/20.
//  Copyright © 2021 Spider. All rights reserved.
//

#ifndef SPPluginDelegate_h
#define SPPluginDelegate_h
#import "SPMessage.h"
#import "SPEnumDefine.h"

@protocol SPPlugin <NSObject>

+ (instancetype)loadPlugin;

-(void)onLogin:(NSString *)appkey userId:(NSString *)userId;

- (BOOL)onReceivedMessage:(SPMessage *)message;

- (void)onConnectionStatusChanged:(SPConnectionStatus)status;

@end
#endif /* SPPluginDelegate_h */
