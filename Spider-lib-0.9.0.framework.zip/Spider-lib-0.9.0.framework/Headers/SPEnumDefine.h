/**
 * Copyright (c) 2019-2020, Spider.
 * All rights reserved.
 *
 * All the contents are the copyright of Spider Network Technology Co.Ltd.
 * Unless otherwise credited. http://Spider.cn
 *
 */

//  SPEnumDefine.h
//  Created by Spider on 5/29/20.

typedef NS_ENUM(NSUInteger, SPConnectionStatus) {
    SPConnectionStatus_Unconnected = 0,
    SPConnectionStatus_Connecting = 1,
    SPConnectionStatus_Connected = 2
};

typedef NS_ENUM(NSUInteger, SPSessionType) {
    SPSessionType_Single = 1,
    SPSessionType_Group = 2,
};

/**
 消息方向

 - MessageDirection_Send: 发送
 - MessageDirection_Receive: 接收
 */
typedef NS_ENUM(NSInteger, SPMessageDirection) {
    SPMessageDirection_Send,
    SPMessageDirection_Receive
};


#pragma mark SPMessageSentStatus - 消息的发送状态
/*!
 消息的发送状态
 */
typedef NS_ENUM(NSUInteger, SPMessageSentStatus) {
    /*!
     已发送成功
     */
    SPMessageSentStatus_Success = 0,
    /*!
     发送中
     */
    SPMessageSentStatus_Sending = 1,

    /*!
     发送失败
     */
    SPMessageSentStatus_Failed = 2,

    
};

#pragma mark SPReceivedStatus - 消息的接收状态
/*!
 消息的接收状态
 */
typedef NS_ENUM(NSUInteger, SPMessageReceivedStatus) {
    /*!
     未读
     */
    SPMessageReceivedStatus_UNREAD = 0,

    /*!
     已读
     */
    SPMessageReceivedStatus_READ = 1,

};

/**
 消息存储类型
 
 - SPMessagePersistFlag_NOT_SAVE_NOT_COUNT: 本地不存储 不计数
 - SPMessagePersistFlag_SAVE: 本地存储，不计数
 - SPMessagePersistFlag_SAVE_AND_COUNT: 本地存储，并计入未读计数
 - SPMessagePersistFlag_TRANSPARENT: 透传消息，不多端同步，如果对端不在线，消息会丢弃
 */
typedef NS_ENUM(NSInteger, SPMessageProfileType) {
    SPMessageProfileType_NOT_SAVE_NOT_COUNT = 0,
    SPMessageProfileType_SAVE_NOT_COUNT = 1,
    SPMessageProfileType_SAVE_AND_COUNT = 2,
    SPMessageProfileType_TRANSPARENT = 3,
};
