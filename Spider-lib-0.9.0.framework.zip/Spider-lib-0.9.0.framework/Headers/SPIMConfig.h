//
//  SPIMConfig.h
//  Spider-lib
//
//  Created by Spider on 2020/6/9.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SPIMConfig : NSObject
@property(nonatomic,copy)NSString *ServerUrl;
@end

NS_ASSUME_NONNULL_END
