//
//  SPUserModel.h
//  Spider-lib
//
//  Created by spider on 2020/6/26.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SPUserModel :  NSObject <NSCoding>

/*!
 用户 ID
 */
@property (nonatomic, copy) NSString *userId;

/*!
 用户名称
 */
@property (nonatomic, copy) NSString *name;

/*!
 用户头像的 URL
 */
@property (nonatomic, copy) NSString *portrait;

/**
 用户信息附加字段
 */
@property (nonatomic, copy) NSString *extra;

- (SPUserModel *)initWithUserId:(NSString *)uId name:(NSString *)name portrait:(NSString *)portrait;
@end

NS_ASSUME_NONNULL_END
