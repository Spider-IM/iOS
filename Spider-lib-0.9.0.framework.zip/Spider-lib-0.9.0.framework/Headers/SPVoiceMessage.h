//
//  SPVoiceMessage.h
//  Spider-lib
//
//  Created by spider on 2020/9/1.
//  Copyright © 2020 Spider. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "SPMessageContent.h"
NS_ASSUME_NONNULL_BEGIN

#define SPVoiceMessageName @"SP:VoiceMsg"

@interface SPVoiceMessage:SPMessageContent
/**
 构造方法

 @param wavData  wav 语音数据
 @return 消息
 */
- (instancetype)initWithData:(NSData *)audioData time:(int)time;
/*!
 wav 格式的音频数据
 */
@property (nonatomic, strong) NSData *audioData;

/*!
 语音消息的时长, 以秒为单位
 */
@property (nonatomic, assign) int time;
@end

NS_ASSUME_NONNULL_END
